<?php 
    
        $con = mysqli_connect("localhost", "root", "", "AndreFerragens");
       
        mysqli_set_charset($con, "utf8");




?>