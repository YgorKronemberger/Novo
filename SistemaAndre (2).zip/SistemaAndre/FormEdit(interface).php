


<!----------------------------- MODAL (EDITAR) --------------------------------------->


<!-- Modal -->
<div class="modal fade" id="modalExemplo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      

      
        
     
            
            <div  class="row corpo" >
                    <div  id="formulario"> <!-- Formulario -->
                        
                    <form  id="segunda"  action="EditarProduto.php" method="POST"><!-- segunda camada -->

                        <div><img style="float:left;" src="img/parafuso.png" alt=""> <img style="float:right;" src="img/parafuso.png" alt=""></div>
                        
                        <h3 class="titulo">Editar Produto</h3> 
                        
                        
                    
                        <img  style="display:block;" class ="divisao img-fluid" src="img/divisorVert.png" alt="Divisor de Menu">

                            
                    
                    
                            <input id="AlteraNome" autofocus type="text" placeholder="Novo Nome Produto" class="form-control mb-4 mt-4">
                            <input id="AlteraProduto" autofocus type="text" placeholder="Novo valor Produto " class="form-control mb-4">
                            <textarea id="AlterarDesc" autofocus type="text" placeholder="Nova Descrição" class="form-control mb-4"></textarea>
                    
                    




                        <img style="display:block;" class ="divisao img-fluid" src="img/divisorVert.png" alt="Divisor de Menu">


                        <input  id="Editar" type="submit" value="Alterar"> <!-- Botão -->
                        
                        
                        <img style="float:left; margin-top:5%;" src="img/parafuso.png" alt=""> <img style="margin-top:5%; float:right;" src="img/parafuso.png" alt=""> <!-- Botões -->
                        
                        </form> <!-- segunda camada -->

                    </div> <!-- Formulario -->
                </div>
         


      </div>
     
    
  </div>
</div>


<!-- -------------------------------- MODAL (EDITAR) ------------------------------------- -->