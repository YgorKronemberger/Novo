

    <div class="row corpo">
        
        <div class="formulario">     
    
            <div class="segunda"> <!-- segunda camada -->

                <div>
                <img style="float:left" src="img/parafuso.png" alt="decoração parafuso"><img class="FotoUsu" width="110"src="img/avatar.png" alt="avatar Site"> <img style="float:right" src="img/parafuso.png" alt="decoração parafuso"></div>

                <form action="GravarLog.php" method="post" class="input-grup grupo">  <!-- Formulario -->

                    <input autofocus placeholder="E-mail" class="email form-control" name="emailLog" type="email">
            
                    <input class="form-control senha" name="SenhaLog" placeholder="Senha" type="password">

                    <a class="esqueceu" href="">Esqueceu sua senha?</a>
                    
                    <input class="botao" type="submit" value="Entrar">

                </form> <!-- Formulario -->
                
                <img class ="divisao img-fluid" src="img/divisorVert.png" alt="Divisor de Menu">

                <div class="botoes">
                <a href=""><button class="botao botao2">Administrador</button></a>
                <a href="cadastro.php"><button class="botao botao1">Cadastrar</button></a>
                
                 
                 <img style="float:left" src="img/parafuso.png" alt="decoração parafuso"><img style="float:right" src="img/parafuso.png" alt="decoração parafuso">
                 
                 </div>
                

            </div> <!-- segunda camada -->
        

        </div>


    </div>
    
    



